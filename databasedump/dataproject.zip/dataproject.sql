-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 03. Jul 2017 um 14:20
-- Server-Version: 10.1.22-MariaDB
-- PHP-Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `dataproject`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `konto`
--

CREATE TABLE `konto` (
  `kontoid` int(11) NOT NULL,
  `kontoname` varchar(50) DEFAULT NULL,
  `straße` varchar(50) DEFAULT NULL,
  `nummer` varchar(5) DEFAULT NULL,
  `plz` varchar(5) DEFAULT NULL,
  `ort` varchar(20) DEFAULT NULL,
  `stnummer` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `konto`
--

INSERT INTO `konto` (`kontoid`, `kontoname`, `straße`, `nummer`, `plz`, `ort`, `stnummer`, `email`) VALUES
(1, 'Chimp GmbH', 'Hauptstraße', '1', '00000', 'Kufstein', 'AT000000000', 'rootuser@gmx.de'),
(2, 'kleineFirma KG', 'Rosenheimerstraße', '2', '88888', 'München', 'DE2233658800', 'rootuser@gmx.de');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `nutzer`
--

CREATE TABLE `nutzer` (
  `email` varchar(50) NOT NULL,
  `geschlecht` enum('f','m') DEFAULT NULL,
  `vname` varchar(20) DEFAULT NULL,
  `nname` varchar(70) DEFAULT NULL,
  `straße` varchar(70) DEFAULT NULL,
  `nummer` varchar(5) DEFAULT NULL,
  `land` varchar(20) DEFAULT NULL,
  `ort` varchar(50) DEFAULT NULL,
  `plz` varchar(5) DEFAULT NULL,
  `telefon` varchar(15) DEFAULT NULL,
  `passwort` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `nutzer`
--

INSERT INTO `nutzer` (`email`, `geschlecht`, `vname`, `nname`, `straße`, `nummer`, `land`, `ort`, `plz`, `telefon`, `passwort`) VALUES
('rootuser@gmx.de', 'm', 'Max', 'Mustermann', 'Hauptstraße ', '1', 'Österreich', 'Kufstein', '00000', '0800666666', '$2y$10$iHXfUY6BeCueFd5yNIImF.jrlaBKnkLxmZPgRiup1sE2ymERnu3Ia');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rechnung`
--

CREATE TABLE `rechnung` (
  `rnnr` int(11) NOT NULL,
  `vname` varchar(50) DEFAULT NULL,
  `nname` varchar(50) DEFAULT NULL,
  `straße` varchar(50) DEFAULT NULL,
  `nummer` varchar(5) DEFAULT NULL,
  `plz` varchar(5) DEFAULT NULL,
  `Ort` varchar(50) DEFAULT NULL,
  `beschreibung` varchar(100) DEFAULT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `kontoid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `rechnung`
--

INSERT INTO `rechnung` (`rnnr`, `vname`, `nname`, `straße`, `nummer`, `plz`, `Ort`, `beschreibung`, `betrag`, `kontoid`) VALUES
(1, 'Peter', 'Müller', 'Seitenstraße', '5', '99999', 'Nürnberg', 'Waren und Dienstleistungen', '50.12', 1),
(2, 'Otto', 'Peters', 'Lidenstraße ', '11', '83043', 'Bad Aibling', '2kg Honig', '12.78', 2),
(3, 'Andreas', 'Musterman', 'Kirchzeile', '2', '83043', 'Kolbermoor', 'Spielzeug', '120.01', 1),
(4, 'Hans', 'Wurst', 'Linkerweg', '1', '77777', 'Stuttgart', 'Weckle', '2.15', 1),
(5, 'Peter', 'Lustig', 'Nebengasse', '8', '83043', 'Bad Aibling', 'Sonnenblumenkerne', '32.00', 1),
(6, 'Axel ', 'Schulz', 'Hauptweg', '55', '00000', 'Berlin', 'Fotokamera', '2330.50', 2);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `konto`
--
ALTER TABLE `konto`
  ADD PRIMARY KEY (`kontoid`),
  ADD KEY `email` (`email`);

--
-- Indizes für die Tabelle `nutzer`
--
ALTER TABLE `nutzer`
  ADD PRIMARY KEY (`email`);

--
-- Indizes für die Tabelle `rechnung`
--
ALTER TABLE `rechnung`
  ADD PRIMARY KEY (`rnnr`),
  ADD KEY `kontoid` (`kontoid`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `konto`
--
ALTER TABLE `konto`
  MODIFY `kontoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `rechnung`
--
ALTER TABLE `rechnung`
  MODIFY `rnnr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
